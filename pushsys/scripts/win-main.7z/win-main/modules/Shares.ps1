net.exe share

Write-Output "Check for any shares that need deleting"

Write-Output "Run ``net share /delete `"<share name>`"`` to delete a share"