sfc.exe /scannow

Dism.exe /Online /Cleanup-Image /RestoreHealth

sfc.exe /scannow